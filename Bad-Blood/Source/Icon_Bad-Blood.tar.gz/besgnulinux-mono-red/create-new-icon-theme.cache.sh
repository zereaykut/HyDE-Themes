gtk-update-icon-cache -f ../$(basename `pwd`)
